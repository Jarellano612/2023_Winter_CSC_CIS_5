/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: blade
 *
 * Created on January 13, 2023, 7:44 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    float first,second,third,fourth,fifth,sum,aveg;
    first = 28;
    second = 32;
    third = 37;
    fourth = 24;
    fifth = 33;
    sum = first+second+third+fourth+fifth;
    aveg = sum/5;
    cout<<aveg;
    return 0;
}

