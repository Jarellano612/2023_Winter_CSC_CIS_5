/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: blade
 *
 * Created on January 13, 2023, 7:51 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    float payPrd,payAmt,anlPay;
    payAmt = 2200.0;
    payPrd = 26;
    anlPay = payAmt*payPrd;
    cout<<"This is the employee's total annual pay: $"<<anlPay;
    return 0;
}

