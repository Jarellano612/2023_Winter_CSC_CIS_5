/* 
 * Author: 
 * Created on 
 * Purpose:  
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes
int collatz(int);//3n+1 sequence

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int n,ns;
    
    //Initialize Variables
    cout<<"Collatz Conjecture Test"<<endl;
    cout<<"Input a sequence start"<<endl;
    cin>>n;
    
    //Process/Map inputs to outputs
    cout<<n;
    ns=collatz(n);
    
    //Output data
    cout<<endl<<"Sequence start of "<<n<<" cycles to 1 in "<<
            ns<<" steps";
    
    //Exit stage right!
    return 0;
}

int collatz(int n){
    int cntr = 1;    
        while(n != 1){
            if(n%2 == 0){ 
                n = n/2; 
                cout << ", "<< n;
                cntr++;
            }
            else{
                n = (3*n) +1;
                cntr++;
                cout << ", "<< n;
            }
        }
        return cntr;
} 