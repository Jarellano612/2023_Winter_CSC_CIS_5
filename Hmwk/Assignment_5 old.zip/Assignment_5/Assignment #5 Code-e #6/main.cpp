/* 
 * File:   
 * Author: 
 * Created on 
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes
string merdiem(char);
void tMath(int&,int&,int);
void intMath(int&,char&);
//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    int hour,min,wait,crnt,newHR,newMin,waitPD;
    char AMPM,again;
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    
    //Display the outputs
    do{  
        cout << "Enter hour:"<<endl<<endl;
        cin>>hour;
        cout << "Enter minutes:"<<endl<<endl;
        cin>>min;
        cout << "Enter A for AM, P for PM:"<<endl<<endl;
        cin>>AMPM;
        cout << "Enter waiting time:"<<endl<<endl;
        cin>>wait;
        intMath(hour,AMPM);
        cout << "Current time = ";
        if(hour < 10){
            cout<<"0";
        }
        cout<<hour<<":";
        if(min < 10){
            cout<<"0";
        }
        cout<<min<<" ";
        cout<<merdiem(AMPM)<<endl;
        tMath(hour,min,wait);
        intMath(hour,AMPM);
        cout << "Time after waiting period = ";
        if(hour < 10){
            cout<<"0";
        }
        cout<<hour<<":";
        if(min < 10){
            cout<<"0";
        }
        cout<<min<<" ";
        cout<<merdiem(AMPM)<<endl<<endl;
        cout <<"Again:"<<endl;
        cin>>again;
        again = tolower(again);
        if(again == 'y'){
            cout<<endl;
        }
    }while(again == 'y');   
    //Exit stage right or left!
    return 0;
}

string merdiem(char AMPM){
    string PMAM;   
        AMPM = toupper(AMPM);
        if(AMPM == 'A'){
            PMAM = "AM";
        }
        else{
            PMAM = "PM";
        }
    return PMAM;
}

void tMath(int& hour,int& min,int wait){
    min = min + wait;
    while(min >= 60){
        hour++;
        min = min - 60;
    }
}

void intMath(int& hour,char& AMPM){
    while(hour > 12){
        hour -= 12;
        if(AMPM == 'A'){
            AMPM = 'P';
        }
        else{
            AMPM = 'A';
        }
    }
}