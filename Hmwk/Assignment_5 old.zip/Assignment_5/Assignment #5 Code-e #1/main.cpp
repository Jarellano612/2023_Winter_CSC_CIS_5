/* 
 * Author: 
 * Created on 
 * Purpose:  
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes
void minmax(int,int,int,int&,int&);//Function to find the min and max

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int numOne,numTwo,numThr,max,min;
    //Initialize Variables
    
    //Process/Map inputs to outputs
    
    //Output data
    cout << "Input 3 numbers" << endl;
    cin>>numOne>>numTwo>>numThr;
    minmax(numOne, numTwo, numThr, min, max);
    cout << "Min = " << min << endl;
    cout << "Max = " << max;
    //Exit stage right!
    return 0;
}
void minmax(int numOne, int numTwo, int numThr, int& min, int& max){
        if(numOne < numTwo && numOne < numThr){
            min = numOne;
        }
        else if(numTwo < numOne && numTwo < numThr){
            min = numTwo;
        }
        else{
            min = numThr;
        }
        if(numOne > numTwo && numOne > numThr){
            max = numOne;
        }
        else if(numTwo > numOne && numTwo > numThr){
            max = numTwo;
        }
        else{
            max = numThr;
        }
}