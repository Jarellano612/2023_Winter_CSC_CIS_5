/* 
 * Author: 
 * Created on 
 * Purpose:  
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes
bool isPrime(int);//Determine if the input number is prime.

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int num;
    //Initialize Variables
    
    //Process/Map inputs to outputs
    
    //Output data
    cout << "Input a number to test if Prime."<<endl;
    cin>>num;
    if(isPrime(num) == true){
        cout << num << " is prime.";
    }
    if(isPrime(num) == false){
        cout << num << " is not prime.";
    }
    //Exit stage right!
    return 0;
}

bool isPrime(int n){
    int i;
        for(int i = 2; i < n/2; i++){
            if(n%i == 0)return false;
        }
        return true;
}